#include"team.h"  //"player.h"<string> <vector>

Team::Team(){

	totalRunsScored = 0;
	wicketLost = 0;
	totalBallsBowled = 0;

}
