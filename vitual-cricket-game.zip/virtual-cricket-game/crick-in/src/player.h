#include<string>


class Player{

	public:
		std::string name;
		int index;
		int runsScored;
		int ballsPlayed;
		int ballsBowled;
		int runsGiven;
		int wicketsTaken;
		Player();


};
